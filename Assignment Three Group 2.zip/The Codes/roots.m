%Define function and derivative
f=@(x) x.^5-2*x.^3+3*x-1;
df=@(x) 5*x.^4-6*x^2+3;
%bisection method
a=0; b=1;
tol=1e-6;
max1=50;
tic
for k=1:max1
    c=(a+b)/2;
    if f(c)==0 || (b-a)/2 <tol
        break;
    end
    if f(a)*f(c)<0
        b=c;
    else
        a=c;
    end
end
root4bisection =c;
time4bisection =toc;
%newton raphson
x0=0.5;
tic
for k=1:max1
    x1=x0-f(x0)/df(x0);
    if abs(x1-x0)<tol
        break;
    end
    x0=x1;
end
root4newton=x1;
time4newton=toc;
%plot
x=linspace(0,2,100);
figure;
plot(x,f(x),'b-','LineWidth',1.5);
hold on
yline(0,'k--');
plot(root4bisection,f(root4bisection),'rx','DisplayName','Bisection Root');
plot(root4newton,f(root4newton),'bo','DisplayName','Newton Root');
legend('f(x)','y=0','Bisection Root','Newton Root');
xlabel('X'); ylabel('f(x)');
title('Root Finding Methods: Bisection vs Newton Raphson');
subtitle(sprintf('Time: Bisection=%.2e s, Newton=%.2e s',time4bisection,time4newton));
grid on;
%Secant method
% Define function
f2 = @(x) sin(x)-x.^2+1;
x0 = 1.0; x1 = 2.0;
tic
for k = 1:max1
    x2 = x1 - f2(x1)*(x1 - x0)/(f2(x1) - f2(x0));
    if abs(x2 - x1) < tol
        break;
    end
    x0 = x1; 
    x1 = x2;
end
root4secant = x2;
time4secant = toc;

%Fixed-Point Iteration
g = @(x) sqrt(sin(x)+1);
x0 = 1.0;
tic
for k = 1:max1
    x1 = g(x0);
    if abs(x1 - x0) < tol
        break;
    end
    x0 = x1;
end
root4fixed = x1;
time4fixed = toc;
% Plot
x = linspace(0,2,100);
figure;
plot(x, f2(x), 'b-', 'LineWidth', 1.5); hold on;
yline(0, 'k--');
plot(root4secant, f2(root4secant), 'r*', 'MarkerSize', 8, 'DisplayName','Secant Root');
plot(root4fixed, f2(root4fixed), 'gs', 'MarkerSize', 8, 'DisplayName','Fixed-Point Root');
legend('f2(x)', 'y=0','Secant Root','Fixed-Point Root');
xlabel('x'); ylabel('f2(x)');
title('Root Finding Methods: Secant vs Fixed-Point Iteration');
subtitle(sprintf('Time: Secant=%.2e s, Fixed=%.2e s',time4secant,time4fixed));
grid on;