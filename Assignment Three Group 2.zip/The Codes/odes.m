% Parameters
% Initial temperature
T1 = 90;          
% environmental temperature
T_env = 25;
v=T_env;
% Cooling rate
k = 0.5;         
% 0 to 60 minutes, step = 1 min
tspan = 0:1:60;    
% ODE function
f = @(T) -k*(T-v); 

%Euler Method
T_euler = zeros(size(tspan));
T_euler(1) = T1;
tic
for i = 1:length(tspan)-1
    T_euler(i+1) = T_euler(i) + f(T_euler(i))*(tspan(i+1)-tspan(i));
end
time4euler = toc;

%Runge-Kutta 4th Order
T_rk4 = zeros(size(tspan));
T_rk4(1) = T1;
tic
for i = 1:length(tspan)-1
    h = tspan(i+1)-tspan(i);
    k1 = f(T_rk4(i));
    k2 = f(T_rk4(i) + 0.5*h*k1);
    k3 = f(T_rk4(i) + 0.5*h*k2);
    k4 = f(T_rk4(i) + h*k3);
    T_rk4(i+1) = T_rk4(i) + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
end
time4rk4 = toc;
T_exact = v + (T1-v)*exp(-k*tspan);
%Plot
figure;
plot(tspan, T_exact, 'k-');
hold on;
plot(tspan, T_euler, 'ro-');
plot(tspan, T_rk4, 'gs-');
xlabel('Time (minutes)'); 
ylabel('Temperature (°C)');
title('Solving differential methods: Euler vs RK4');
subtitle(sprintf('Time: Euler=%.2e s, RK4=%.2e s',time4euler,time4rk4));
legend('Analytical','Euler','RK4');
grid on;
%Heun Method
T_heun = zeros(size(tspan));
T_heun(1) = T1;
tic
for i = 1:length(tspan)-1
    h = tspan(i+1)-tspan(i);
    k1 = f(T_heun(i));

    k2 = f(T_heun(i) + h*k1);
    T_heun(i+1) = T_heun(i) + (h/2)*(k1 + k2);
end
time4heun = toc;

%Midpoint Method
T_mid = zeros(size(tspan));
T_mid(1) = T1;
tic
for i = 1:length(tspan)-1
    h = tspan(i+1)-tspan(i);
    k1 = f(T_mid(i));
    k2 = f(T_mid(i) + 0.5*h*k1);
    T_mid(i+1) = T_mid(i) + h*k2;
end
time4mid = toc;
%Plot
figure;
plot(tspan, T_exact, 'k-');
hold on;
plot(tspan, T_heun, '-co');
plot(tspan, T_mid, 'rx-');
xlabel('Time (minutes)'); 
ylabel('Temperature (°C)');
title('Solving differential equations methods: Heun vs Midpoint');
subtitle(sprintf('Time: Heun=%.2e s, Midpoint=%.2e s',time4heun,time4mid));
legend('Analytical','Heun','Midpoint');
grid on;

